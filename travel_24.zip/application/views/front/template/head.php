<header id="masthead" class="site-header sticky_header affix-top">
	<div class="header_top_bar">
		<div class="container">
			<div class="row">
				<div class="col-sm-4">
					<aside id="text-15" class="widget_text">
						<div class="textwidget">
							<ul class="top_bar_info clearfix">
								<li><i class="fa fa-envelope-o"></i> info@thetravelfirm</li>
								<li><i class="fa fa-phone"></i>+91-97024 83622</li>
							</ul>
						</div>
					</aside>
				</div>
				<div class="col-sm-8 topbar-right">
					<aside id="text-7" class="widget widget_text">
						<div class="textwidget">
							<ul class="top_bar_info clearfix">
								<li class="<?php if ($page=='about'){echo 'current-menu-ancestor';}?>" onclick="window.location.href='<?= base_url('home/about_us')?>';"><i class="fa fa-edit"></i> About Us</li>
								<li class="<?php if ($page == 'testimonial'){echo 'current-menu-ancestor';}?>hidden-info" onclick="window.location.href='<?= base_url('home/testimonial')?>';">
									<i class="fa fa-microphone"></i> Testimonial</li>
							</ul>
						</div>
					</aside>

				</div>
			</div>
		</div>
	</div>

