<?php $page = 'testimonial'; include APPPATH ."views/front/template/header.php";?>

<?php include APPPATH ."views/front/template/head.php";?>

<?php include APPPATH ."views/front/template/navigation.php";?>

<!-- -----------------page content start here ------------------ -->

<div class="site wrapper-content">
	<div class="top_site_main">
		<div class="banner-wrapper container article_heading">
			<div class="breadcrumbs-wrapper">
				<ul class="phys-breadcrumb">
					<li><a href="index.html" class="home">Home</a></li>
					<li><a href="">Testimonial </a></li>
				</ul>
			</div>
			<h2 class="heading_primary">Testimonial</h2></div>
	</div>

	<div class="section-white padding-top-6x padding-bottom-6x">
		<div class="container">
			<div class="row">
				<div class="col-sm-12">
					<div class="shortcode_title title-center title-decoration-bottom-center">
						<h2 class="title_primary">Tours Reviews</h2>
						<span class="line_after_title"></span>
					</div>
					<div class="shortcode-tour-reviews wrapper-tours-slider">
						<div class="tours-type-slider" data-autoplay="true" data-dots="true" data-nav="false" data-responsive='{"0":{"items":1}, "480":{"items":1}, "768":{"items":1}, "992":{"items":1}, "1200":{"items":1}}'>
						 <?php if (count($testimonial)):?>
						    <?php foreach ($testimonial as $testimonial):?>
							<div class="tour-reviews-item">
								<div class="reviews-item-info">
									<img alt="" src="<?= $testimonial->client_img?>" class="avatar avatar-95 photo" height="90" width="90">
									<!-- <div class="reviews-item-info-name">Pradeep Kushwaha</div>-->
									<div class="reviews-item-rating">
										<i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i>
									</div>
								</div>
								<div class="reviews-item-content">
									<h3 class="reviews-item-title">
										<a href="#"><?= $testimonial->client_name;?></a>
									</h3>
									<div class="reviews-item-description"><?= $testimonial->review;?></div>
								</div>
							</div>
						    <?php endforeach;?>
						 <?php endif;?>

						</div>
					</div>
				</div>

			</div>
		</div>
	</div>
</div>





<!-- -----------------../page content start here ------------------ -->

<?php include APPPATH ."views/front/template/footer.php";?>
