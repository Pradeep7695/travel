<?php $page ='home'; include APPPATH ."views/front/template/header.php";?>

<?php include APPPATH ."views/front/template/head.php";?>

<?php include APPPATH ."views/front/template/navigation.php";?>

<!-- -----------------page content start here ------------------ -->

<div class="site wrapper-content">
	<div class="home-content" role="main">

		<!-- ------------------start rev slider ------------- -->
		<div id="banner">

			<!-- Slider begins here -->
			<div id="homepage_slider" class="carousel slide">
				<!--<ol class="carousel-indicators">
					<li data-target="#homepage_slider" data-slide-to="0" class="active"></li>
					<li data-target="#homepage_slider" data-slide-to="1"></li>
					<li data-target="#homepage_slider" data-slide-to="1"></li>
				</ol>-->

				<!-- Carousel items -->
				<div class="carousel-inner">

		<!-- ------------------video  slide #1 ---------------->
				<?php if (count($videoSlider)):?>
					<?php foreach ($videoSlider as $item):?>
					<div data-slide="0" class="item active">
						<div class="slider-hide-on-mobile">
							<video id="bgvid" autoplay loop muted poster="">
								<source src="<?= $item->video?>" type="video/mp4"></video>
						</div>
					</div>
					<?php endforeach;?>
				<?php endif;?>
	 <!-- -------------..//end video slider ----------- -->

     <!-- -------------------img slider -------------------- -->
					<?php if ($slider):?>
						<?php foreach ($slider as $item):?>
					<!-- slide #2 (image) -->
					<div class="item">
						<img alt="<?= $item->slider_title;?>" src="<?= $item->slider_img;?>">
					</div>
					<!-- slide #3 (image) -->

					  <?php endforeach;?>
				  <?php endif;?>
				</div> <!-- end of '.carousel-inner' -->

				<!-- Carousel nav -->
				<!-- 	<div id="slider-play-button"><button class="play-video-button" type="button" title="Play Video"></button></div> -->
				<a class="carousel-control left" href="#homepage_slider" data-slide="prev">&lsaquo;</a>
				<a class="carousel-control right" href="#homepage_slider" data-slide="next">&rsaquo;</a>
			</div> <!-- end of '#homepage_slider' -->
			<!-- Slider ends here -->

		</div>  <!-- end of "#banner" -->

		<!-- -------------------end rev slider ------------------- -->
		<section class="form-slder">
			<div class="slider-tour-booking">
				<div class="container">
					<div class="travel-booking-search hotel-booking-search travel-booking-style_1">
						<form name="table_form" action="" id="regform" method="post">
							<ul class="hb-form-table">
								<li class="hb-form-field">
									<div class="hb-form-field-input hb_input_field">
										<input type="text" name="name" value="" placeholder="Name" required>
									</div>
								</li>
								<li class="hb-form-field">
									<div class="hb-form-field-input hb_input_field">
										<input type="text" name="mobile" value="" placeholder="Mobile No." required>
									</div>
								</li>
								<li class="hb-form-field">
									<div class="hb-form-field-input hb_input_field">
										<input type="email" name="email" value="" placeholder="Email" required>
									</div>
								</li>
								<li class="hb-form-field">
									<div class="hb-form-field-input hb_input_field">
										<input type="text" name="destination" value="" placeholder="Destination" required>
									</div>
								</li>
								<li class="hb-submit">
									<button type="submit" value="Enquiry Now">Enquiry Now</button>
								</li>
							</ul>
							<input type="hidden" name="lang" value="">

						</form>
					</div>
				</div>
			</div>
		</section>


		<div class="container two-column-respon mg-top-6x mg-bt-6x">
			<div class="row">
				<div class="col-sm-12 mg-btn-6x">
					<div class="shortcode_title title-center title-decoration-bottom-center">
						<h3 class="title_primary">WHY CHOOSE US?</h3><span class="line_after_title"></span>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="wpb_column col-sm-3">
					<div class="widget-icon-box widget-icon-box-base iconbox-center tr-border">
						<div class="boxes-icon circle" style="font-size:30px;width:80px; height:80px;line-height:80px">
							<span class="inner-icon"><i class="vc_icon_element-icon flaticon-transport-6"></i></span>
						</div>
						<div class="content-inner">
							<div class="sc-heading article_heading">
								<h4 class="heading__primary">Diverse Destinations</h4></div>
							<div class="desc-icon-box">
								<div>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod.</div>
							</div>
						</div>
					</div>
				</div>
				<div class="wpb_column col-sm-3">
					<div class="widget-icon-box widget-icon-box-base iconbox-center tr-border">
						<div class="boxes-icon " style="font-size:30px;width:80px; height:80px;line-height:80px">
							<span class="inner-icon"><i class="vc_icon_element-icon flaticon-sand"></i></span>
						</div>
						<div class="content-inner">
							<div class="sc-heading article_heading">
								<h4 class="heading__primary">Value for Money</h4></div>
							<div class="desc-icon-box">
								<div>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod.</div>
							</div>
						</div>
					</div>
				</div>
				<div class="wpb_column col-sm-3">
					<div class="widget-icon-box widget-icon-box-base iconbox-center tr-border">
						<div class="boxes-icon " style="font-size:30px;width:80px; height:80px;line-height:80px">
							<span class="inner-icon"><i class="vc_icon_element-icon flaticon-travel-2"></i></span>
						</div>
						<div class="content-inner">
							<div class="sc-heading article_heading">
								<h4 class="heading__primary">Beautiful Places</h4></div>
							<div class="desc-icon-box">
								<div>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod.</div>
							</div>
						</div>
					</div>
				</div>
				<div class="wpb_column col-sm-3">
					<div class="widget-icon-box widget-icon-box-base iconbox-center tr-border">
						<div class="boxes-icon circle" style="font-size:30px;width:80px; height:80px;line-height:80px">
							<span class="inner-icon"><i class="vc_icon_element-icon flaticon-travelling"></i></span>
						</div>
						<div class="content-inner">
							<div class="sc-heading article_heading">
								<h4 class="heading__primary">Passionate Travel</h4></div>
							<div class="desc-icon-box">
								<div>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod.</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>

		<div class="padding-top-6x padding-bottom-6x section-background2">
			<div class="container">
				<div class="shortcode_title text-white title-center title-decoration-bottom-center">
					<div class="title_subtitle">Take a Look at Our</div>
					<h3 class="title_primary">MOST POPULAR TOURS</h3>
					<span class="line_after_title" style="color:#ffffff"></span>
				</div>
				<div class="row wrapper-tours-slider">
					<div class="tours-type-slider list_content" data-dots="true" data-nav="true" data-responsive='{"0":{"items":1}, "480":{"items":2}, "768":{"items":2}, "992":{"items":3}}'>
						<?php if ($popularTour):?>
							<?php foreach ($popularTour as $item):?>
								<div class="item-tour">
									<div class="radius-mask tour-block hover-aqua">
										<div class="clip" onclick="window.location.href='details.html';">
											<img src="<?= $item->package_img;?>">
										</div>
										<div class="tour-layer delay-1"></div>
										<div class="tour-caption">
											<div class="vertical-align">
												<h3 class="hover-it"><?= $item->package_name?></h3>

												<h4>from <b><i class="fa fa-inr"></i> <?= $item->package_price;?></b></h4>
											</div>
											<div class="vertical-bottom">
												<a href="<?= $item->url_link?>" target="_blank" class="c-button b-50 bg-aqua hv-transparent fr"><span class="fa fa-eye"></span> View Details</a>
											</div>
										</div>
									</div>
								</div>
							<?php endforeach;?>
						<?php endif;?>


					</div>
				</div>
			</div>
		</div>
		<div class="section-white padding-top-6x padding-bottom-6x tours-type">
			<div class="container">
				<div class="shortcode_title title-center title-decoration-bottom-center">
					<div class="title_subtitle">Find a Tour by</div>
					<h3 class="title_primary">DESTINATION</h3><span class="line_after_title"></span>
				</div>
				<div class="wrapper-tours-slider wrapper-tours-type-slider">
					<div class="tours-type-slider" data-dots="true" data-nav="true" data-responsive='{"0":{"items":1}, "480":{"items":2}, "768":{"items":3}, "992":{"items":4}}'>
						<div class="tours_type_item">
							<a href="<?= base_url('home/contact_us')?>" class="tours-type__item__image">
								<img src="<?= base_url('assets/front/images/city/26003147786_a04226cd2f_o.jpg')?>" alt="Brazil">
							</a>
							<div class="content-item">
								<div class="item__title">Brazil</div>
							</div>
						</div>
						<div class="tours_type_item">
							<a href="<?= base_url('home/contact_us')?>" class="tours-type__item__image">
								<img src="<?= base_url('assets/front/images/city/24987002020_29d3944b4f_o.jpg')?>" alt="Philippines">
							</a>
							<div class="content-item">
								<div class="item__title">Philippines</div>
							</div>
						</div>
						<div class="tours_type_item">
							<a href="<?= base_url('home/contact_us')?>" class="tours-type__item__image">
								<img src="<?= base_url('assets/front/images/city/25816508131_00e16429b8_o.jpg')?>" alt="Italy">
							</a>
							<div class="content-item">
								<div class="item__title">Italy</div>
							</div>
						</div>
						<div class="tours_type_item">
							<a href="<?= base_url('home/contact_us')?>" class="tours-type__item__image">
								<img src="<?= base_url('assets/front/images/city/photo-1474181487882-5abf3f0ba6c2.jpg')?>" alt="USA">
							</a>
							<div class="content-item">
								<div class="item__title">USA</div>
							</div>
						</div>
						<div class="tours_type_item">
							<a href="<?= base_url('home/contact_us')?>" class="tours-type__item__image">
								<img src="<?= base_url('assets/front/images/city/25656857141_edcdf5e6e3_o.jpg')?>" alt="Canada">
							</a>
							<div class="content-item">
								<div class="item__title">Canada</div>
							</div>
						</div>
						<div class="tours_type_item">
							<a href="" class="tours-type__item__image">
								<img src="<?= base_url('assets/front/images/city/26003147786_a04226cd2f_o.jpg')?>" alt="Cuba">
							</a>
							<div class="content-item">
								<div class="item__title">Cuba</div>
							</div>
						</div>
						<div class="tours_type_item">
							<a href="<?= base_url('home/contact_us')?>" class="tours-type__item__image">
								<img src="<?= base_url('assets/front/images/city/25656857141_edcdf5e6e3_o.jpg')?>" alt="Brazil">
							</a>
							<div class="content-item">
								<div class="item__title">Brazil</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="padding-top-6x padding-bottom-6x bg__shadow section-background">
			<div class="container">
				<div class="shortcode_title text-white title-center title-decoration-bottom-center">
					<!--	<div class="title_subtitle">Some statistics about Travel WP</div>-->
					<h3 class="title_primary">Need Inspiration for Your Next Tour? Travel the World You Never Seen</h3>
					<span class="line_after_title" style="color:#ffffff"></span>
				</div>
				<!--<div class="row">
                    <div class="col-md-12">
                        <div class="text-cont">
                            <p>Need Inspiration for Your Next Tour? Travel the World You Never Seen</p>
                        </div>
                    </div>
                </div>-->
				<div class="row">
					<div class="col-sm-12 text-center padding-top-6x">
						<a href="<?= base_url('home/contact_us')?>" class="icon-btn" title="">
							<i class="fa fa-phone"></i> Contact Now
						</a>
					</div>
				</div>
			</div>
		</div>

	</div>
</div>



<!-- -----------------../page content start here ------------------ -->

<?php include APPPATH ."views/front/template/footer.php";?>


<script>
	// without this script, the slider doesn't start on it's own:
	!function ($) {
		$(function(){
			$('#homepage_slider').carousel()
		})
	}(window.jQuery)


	// if user chooses to not autoplay the video, the button should be uncommented in html and this script will make the button work:
	var vid = document.getElementById("bgvid");
	var playButton = document.querySelector("#slider-play-button button");

	playButton.addEventListener("click", function() {
		if (vid.paused) {
			vid.play();
			playButton.classList.remove("play-video-button");
			playButton.classList.add("pause-video-button");
		} else {
			vid.pause();
			playButton.classList.add("play-video-button");
			playButton.classList.remove("pause-video-button");
		}
	});
</script>
