<?php /*include APPPATH ."views/front/template/header.php";*/?><!--

<?php /*include APPPATH ."views/front/template/head.php";*/?>

<?php /*include APPPATH ."views/front/template/navigation.php";*/?>

<!-- -----------------page content start here ------------------ -->







<!-- -----------------../page content start here ------------------ -->

--><?php /*include APPPATH ."views/front/template/footer.php";*/?>
