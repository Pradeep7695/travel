<?php $page = 'about'; include APPPATH ."views/front/template/header.php";?>

<?php include APPPATH ."views/front/template/head.php";?>

<?php include APPPATH ."views/front/template/navigation.php";?>

<!-- -----------------page content start here ------------------ -->

<div class="site wrapper-content">
	<div class="top_site_main">
		<div class="banner-wrapper container article_heading">
			<div class="breadcrumbs-wrapper">
				<ul class="phys-breadcrumb">
					<li><a href="<?= base_url('home')?>" class="home">Home</a></li>
					<li><a href="">About Us </a></li>
				</ul>
			</div>
			<h2 class="heading_primary">About Us</h2></div>
	</div>

	<section class="why_choose section-padding gray-section">
	 <?php if ($about):?>
	   <?php foreach ($about as $about):?>
		<div class="container">
			<div class="row">
				<div class="col-md-12 aos-init" data-aos="fade-up">
					<div class="section-title text-center">
						<h2>why choose us</h2>
						<span></span>
						<p>
							<?= $about->about_desc;?>
						</p>

					</div>
				</div><!-- END COL -->
			</div><!-- END ROW -->

			<div class="row text-center">
				<div class="col-md-5">
					<div class="why-choose-img">
						<figure class="big-img">
							<img src="<?= $about->about_img; ?>" alt="">
						</figure>

					</div>
				</div>

				<div class="col-md-7 mt-40">
					<div class="row">
						<div class="col-sm-6 col-xs-12">
							<div class="single-choose">
								<i class="fa fa-star"></i>
								<h4>Handpicked Hotels</h4>
								<p><?= $about->service1?></p>
							</div>
						</div><!-- END COL -->

						<div class="col-sm-6 col-xs-12">
							<div class="single-choose">
								<i class="fa fa-globe"></i>
								<h4>World Class Service</h4>
								<p><?= $about->service2?></p>
							</div>
						</div><!-- END COL -->

						<div class="col-sm-6 col-xs-12">
							<div class="single-choose">
								<i class="fa fa-thumbs-up"></i>
								<h4>Best Price Guarantee</h4>
								<p><?= $about->service3?></p>
							</div>
						</div><!-- END COL -->

						<div class="col-sm-6 col-xs-12">
							<div class="single-choose">
								<i class="fa fa-shield "></i>
								<h4>Secure Travel</h4>
								<p><?= $about->service4?></p>
							</div>
						</div><!-- END COL -->
					</div>
				</div>

			</div><!-- END ROW -->
		</div><!-- END CONTAINER -->
	   <?php endforeach;?>
	<?php endif;?>
	</section>

</div>





<!-- -----------------../page content start here ------------------ -->

<?php include APPPATH ."views/front/template/footer.php";?>
